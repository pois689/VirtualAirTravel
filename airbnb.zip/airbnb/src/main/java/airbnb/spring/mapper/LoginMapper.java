package airbnb.spring.mapper;

public interface LoginMapper { //crud create,read,delete,update
	
}
