package airbnb.spring.dto;

public class User {
	
}
