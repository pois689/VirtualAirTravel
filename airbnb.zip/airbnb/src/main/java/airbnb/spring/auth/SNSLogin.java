package airbnb.spring.auth;

public class SNSLogin{

}