package airbnb.spring.service;

public interface LoginService {

}
